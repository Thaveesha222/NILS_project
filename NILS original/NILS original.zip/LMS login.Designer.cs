﻿namespace NILS_original
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.btn_short = new ePOSOne.btnProduct.Button_WOC();
            this.btn_login_staff = new ePOSOne.btnProduct.Button_WOC();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_login_stud = new ePOSOne.btnProduct.Button_WOC();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.metroPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroPanel1.BackgroundImage")));
            this.metroPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.metroPanel1.Controls.Add(this.btn_short);
            this.metroPanel1.Controls.Add(this.btn_login_staff);
            this.metroPanel1.Controls.Add(this.label1);
            this.metroPanel1.Controls.Add(this.btn_login_stud);
            this.metroPanel1.Controls.Add(this.pictureBox1);
            this.metroPanel1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(0, 24);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(801, 423);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // btn_short
            // 
            this.btn_short.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_short.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_short.BackgroundImage")));
            this.btn_short.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_short.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_short.ButtonColor = System.Drawing.SystemColors.Highlight;
            this.btn_short.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_short.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_short.Location = new System.Drawing.Point(559, 221);
            this.btn_short.Name = "btn_short";
            this.btn_short.OnHoverBorderColor = System.Drawing.Color.White;
            this.btn_short.OnHoverButtonColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_short.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_short.Size = new System.Drawing.Size(183, 95);
            this.btn_short.TabIndex = 15;
            this.btn_short.Text = "Short courses";
            this.btn_short.TextColor = System.Drawing.Color.White;
            this.btn_short.UseVisualStyleBackColor = false;
            // 
            // btn_login_staff
            // 
            this.btn_login_staff.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_login_staff.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_login_staff.BackgroundImage")));
            this.btn_login_staff.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_login_staff.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_login_staff.ButtonColor = System.Drawing.SystemColors.Highlight;
            this.btn_login_staff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login_staff.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login_staff.Location = new System.Drawing.Point(300, 221);
            this.btn_login_staff.Name = "btn_login_staff";
            this.btn_login_staff.OnHoverBorderColor = System.Drawing.Color.White;
            this.btn_login_staff.OnHoverButtonColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_login_staff.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_login_staff.Size = new System.Drawing.Size(183, 95);
            this.btn_login_staff.TabIndex = 14;
            this.btn_login_staff.Text = "Login as Staff";
            this.btn_login_staff.TextColor = System.Drawing.Color.White;
            this.btn_login_staff.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(57, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(702, 34);
            this.label1.TabIndex = 13;
            this.label1.Text = "Welcome to National Institite Of Labour Studies LMS";
            // 
            // btn_login_stud
            // 
            this.btn_login_stud.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_login_stud.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_login_stud.BackgroundImage")));
            this.btn_login_stud.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_login_stud.BorderColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_login_stud.ButtonColor = System.Drawing.SystemColors.Highlight;
            this.btn_login_stud.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_login_stud.Font = new System.Drawing.Font("Lucida Sans Unicode", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login_stud.Location = new System.Drawing.Point(63, 221);
            this.btn_login_stud.Name = "btn_login_stud";
            this.btn_login_stud.OnHoverBorderColor = System.Drawing.Color.White;
            this.btn_login_stud.OnHoverButtonColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_login_stud.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_login_stud.Size = new System.Drawing.Size(183, 95);
            this.btn_login_stud.TabIndex = 6;
            this.btn_login_stud.Text = "Login as Student";
            this.btn_login_stud.TextColor = System.Drawing.Color.White;
            this.btn_login_stud.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(357, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 91);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.metroPanel1);
            this.Name = "Form1";
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private ePOSOne.btnProduct.Button_WOC btn_login_stud;
        private System.Windows.Forms.Label label1;
        private ePOSOne.btnProduct.Button_WOC btn_short;
        private ePOSOne.btnProduct.Button_WOC btn_login_staff;
    }
}